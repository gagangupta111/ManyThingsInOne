package com.HackerEarth.chess;

import java.util.ArrayList;
import java.util.List;

public class Board {

    public static final String BLACK = "Black";
    public static final String WHITE = "White";

    private Spot[][] spots = new Spot[8][8];

    public Board() {
        super();
        for(int i=0; i<spots.length; i++){
            for(int j=0; j<spots.length; j++){
                this.spots[i][j] = new Spot(i, j);
            }
        }
    }

    public Spot getSpot(int x, int y) {
        return spots[x][y];
    }

    public List<Spot> getAllSpots(int fromX, int fromY, int toX, int toY) {

        List<Spot> spots  = new ArrayList<>();
        // diagonal up
        if (fromX < toX && fromY < toY ){
            while (fromX != fromY && toX != toY){
                spots.add(getSpot(fromX++, fromY++));
            }
        }

        if (fromX < toX && fromY > toY ){
            while (fromX != fromY && toX != toY){
                spots.add(getSpot(fromX++, fromY--));
            }
        }

        if (fromX > toX && fromY < toY ){
            while (fromX != fromY && toX != toY){
                spots.add(getSpot(fromX--, fromY++));
            }
        }

        if (fromX > toX && fromY > toY ){
            while (fromX != fromY && toX != toY){
                spots.add(getSpot(fromX--, fromY--));
            }
        }

        return spots;

    }

}